ESPORTSIQ — BIG DATA ANALYTICS IN E-SPORTS AND GAMING
====================================================

QUICK START (no Python, no installation, no internet required)
1. Extract Esports_Big_Data_Analytics.zip.
2. Open the extracted folder.
3. Double-click index.html. It opens in Chrome, Edge, or Firefox.
4. Use Game Title / Team / Search filters.
5. Click "Export filtered CSV" to download the selected records.

PROJECT OVERVIEW
EsportsIQ is a browser-based analytics application that transforms match records into useful performance insights. It calculates win rate, average kill/death ratio, average score, match duration, game distribution, and a player leaderboard. It includes interactive filters and CSV export.

FEATURES
- 40 sample match records are embedded in app.js for instant offline launch.
- Game, team, and player/team search filters.
- KPI calculations update immediately when filters change.
- Game distribution bar chart and win/loss doughnut chart.
- Player leaderboard ranked by average score.
- Match record explorer and CSV export of filtered records.
- Responsive dark esports-inspired design.
- No backend, database server, Python, package manager, or third-party library required.

FILES
index.html                 Main application interface
styles.css                 Responsive design and styling
app.js                     Dataset, analytics logic, charts, filters, export
data/gaming_matches.csv    Sample dataset file (starter sample)
Project_Report.md          Project documentation
Viva_Questions.txt         Viva preparation
