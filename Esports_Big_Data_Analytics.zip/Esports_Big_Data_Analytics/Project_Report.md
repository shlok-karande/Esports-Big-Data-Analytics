# Big Data Analytics in E-Sports and Gaming — EsportsIQ

## 1. Abstract
EsportsIQ is a browser-based analytics project designed to demonstrate how gaming match data can be transformed into useful performance information. The application processes match records and calculates win rate, average kill/death ratio, average score, match duration, game-wise match volume, and player rankings. Interactive filters let a user explore data by game, team, or player, while CSV export supports further analysis. The project uses a sample dataset and runs locally in a web browser without server installation.

## 2. Problem Statement
Esports generates large volumes of match and player statistics. Reviewing raw records manually makes it difficult to compare performance, find consistent players, and understand win/loss trends. A compact analytics tool can summarize key indicators and make the records easier to explore.

## 3. Objectives
- Convert raw match records into understandable statistics.
- Compare players using average score and K/D ratio.
- Calculate win rate and match-duration averages.
- Compare match volume across game titles.
- Filter records and export selected data for further analysis.
- Demonstrate core data analytics concepts in an accessible web application.

## 4. Scope
The project is a prototype using 40 fictional sample match records embedded in the JavaScript source. It is intended for academic demonstration, not for real-time professional esports scouting. Live APIs, user authentication, and server-side storage are outside the current version.

## 5. Technologies Used
- HTML5: page structure.
- CSS3: responsive user interface and visualizations.
- JavaScript: data processing, aggregation, filtering, and CSV export.
- CSV: portable tabular data format.
- Browser DOM APIs: dynamic rendering and file download.

## 6. System Requirements
Hardware: any standard computer with 2 GB RAM or more.
Software: Windows/macOS/Linux and a modern browser such as Chrome, Edge, or Firefox.
No Python, Node.js, database, or internet connection is required to run the application.

## 7. Modules
1. Dataset module: stores match date, game, player, team, opponent, result, kills, deaths, assists, score, and duration.
2. Filter module: filters by selected game, team, and search text.
3. KPI module: calculates win rate, average K/D, average score, and average duration.
4. Game distribution module: counts records for each game and displays proportional bars.
5. Player leaderboard: groups records by player, team, and game; ranks by average score.
6. Record explorer: displays filtered raw records.
7. Export module: creates a downloadable CSV containing filtered rows.

## 8. Methodology / Algorithms
For the selected records:
- Win Rate (%) = (Number of wins / Number of selected matches) × 100
- Average Score = Sum of player scores / Number of selected matches
- Average K/D = Average kills / Average deaths
- Average Duration = Sum of match durations / Number of selected matches
- Game distribution = Count records belonging to each game title
- Player ranking = Group records by player/team/game, calculate average score, then sort in descending order.

Filtering happens before calculations, so every KPI and chart updates to reflect the selected subset. Empty results are handled without crashing.

## 9. Implementation
Open `index.html` in a browser. The application loads its sample data from `app.js`, builds filter options, and renders the page. Changing a filter triggers `render()`, which recalculates the metrics and updates the visual components. The Export button converts the current filtered records into CSV and triggers a browser download.

## 10. Testing
| Test | Action | Expected result |
|---|---|---|
| Initial launch | Open index.html | Metrics, charts and tables appear |
| Game filter | Select Valorant | All visible analytics use Valorant records |
| Team filter | Select a team | Only that team's records are analysed |
| Search | Type a player name | Matching rows and KPIs update |
| Reset | Click Reset filters | All records are restored |
| Export | Click Export filtered CSV | CSV of selected rows downloads |
| No matches | Search a non-existing name | Empty states show; page remains functional |
| Responsive layout | Resize browser | Layout adapts for mobile/tablet |

## 11. Sample Output
On launch, the application shows 40 match records. The interface displays the selected-record win rate, average K/D ratio, average score, average match duration, a game distribution chart, win/loss ratio, a top-performers table, and raw match records. Values change when filters are used.

## 12. Advantages
- Easy to run and demonstrate.
- No installation or internet dependency.
- Fast interactive summaries of raw data.
- Export supports external spreadsheet analysis.
- Responsive layout and understandable visualizations.

## 13. Limitations and Future Enhancements
The sample data is fictional and small compared with real big-data systems. Future versions could ingest public esports APIs, store data in a database, use a backend for large-scale processing, add time-series trends, and use predictive models for player or match outcome estimation. A true production big-data pipeline could use Kafka for streaming, Spark for distributed processing, and a data lake for historical records.

## 14. Conclusion
EsportsIQ demonstrates the basic big-data analytics workflow of collecting structured match records, filtering and aggregating data, presenting performance indicators, and exporting results. It offers a working foundation for exploring esports statistics and can be extended into a scalable analytics pipeline.

## 15. References
- MDN Web Docs — HTML, CSS, and JavaScript documentation: https://developer.mozilla.org/
- RFC 4180 — Common Format and MIME Type for CSV Files: https://www.rfc-editor.org/rfc/rfc4180
