const DATA = [
["2026-08-01","Valorant","Nova","Team Zenith","Ravens",1,18,11,7,286,34],
["2026-08-01","Valorant","Blaze","Team Zenith","Ravens",1,22,13,5,312,34],
["2026-08-02","Valorant","Rift","Ravens","Team Zenith",0,14,17,4,221,34],
["2026-08-02","Valorant","Echo","Ravens","Team Zenith",0,16,19,8,245,34],
["2026-08-03","League of Legends","Luna","Pixel Forge","Dragon Core",1,8,3,14,410,29],
["2026-08-03","League of Legends","Vex","Pixel Forge","Dragon Core",1,11,5,9,438,29],
["2026-08-04","League of Legends","Drake","Dragon Core","Pixel Forge",0,5,8,6,301,29],
["2026-08-04","League of Legends","Mako","Dragon Core","Pixel Forge",0,7,10,4,320,29],
["2026-08-05","PUBG","Ghost","Storm Unit","Red Wolves",1,7,2,3,520,26],
["2026-08-05","PUBG","Karma","Storm Unit","Red Wolves",1,5,3,6,465,26],
["2026-08-06","PUBG","Frost","Red Wolves","Storm Unit",0,3,5,2,340,26],
["2026-08-06","PUBG","Ace","Red Wolves","Storm Unit",0,4,6,3,355,26],
["2026-08-07","Counter-Strike 2","Stryker","Iron Pulse","Night Shift",1,24,16,6,388,41],
["2026-08-07","Counter-Strike 2","Hex","Iron Pulse","Night Shift",1,19,14,9,351,41],
["2026-08-08","Counter-Strike 2","Cipher","Night Shift","Iron Pulse",0,17,20,4,294,41],
["2026-08-08","Counter-Strike 2","Jett","Night Shift","Iron Pulse",0,15,22,7,275,41],
["2026-08-09","Valorant","Nova","Team Zenith","Iron Pulse",1,21,12,8,301,38],
["2026-08-09","Valorant","Blaze","Team Zenith","Iron Pulse",0,17,18,6,268,38],
["2026-08-10","League of Legends","Luna","Pixel Forge","Storm Unit",0,6,7,12,365,33],
["2026-08-10","League of Legends","Vex","Pixel Forge","Storm Unit",1,13,4,11,492,33],
["2026-08-11","PUBG","Ghost","Storm Unit","Pixel Forge",1,8,1,4,570,24],
["2026-08-11","PUBG","Karma","Storm Unit","Pixel Forge",1,6,2,8,498,24],
["2026-08-12","Counter-Strike 2","Stryker","Iron Pulse","Ravens",0,16,19,5,302,37],
["2026-08-12","Counter-Strike 2","Hex","Iron Pulse","Ravens",1,23,13,8,376,37],
["2026-08-13","Valorant","Echo","Ravens","Night Shift",1,20,14,10,322,31],
["2026-08-13","Valorant","Rift","Ravens","Night Shift",0,12,18,5,230,31],
["2026-08-14","League of Legends","Drake","Dragon Core","Iron Pulse",1,10,6,13,405,32],
["2026-08-14","League of Legends","Mako","Dragon Core","Iron Pulse",0,4,9,8,280,32],
["2026-08-15","PUBG","Ace","Red Wolves","Night Shift",1,9,2,4,590,22],
["2026-08-15","PUBG","Frost","Red Wolves","Night Shift",1,6,3,5,475,22],
["2026-08-16","Counter-Strike 2","Cipher","Night Shift","Pixel Forge",1,22,15,7,365,39],
["2026-08-16","Counter-Strike 2","Jett","Night Shift","Pixel Forge",0,14,18,9,290,39],
["2026-08-17","Valorant","Nova","Team Zenith","Dragon Core",1,25,10,6,390,36],
["2026-08-17","Valorant","Blaze","Team Zenith","Dragon Core",1,20,14,9,330,36],
["2026-08-18","League of Legends","Luna","Pixel Forge","Ravens",1,12,4,16,510,31],
["2026-08-18","League of Legends","Vex","Pixel Forge","Ravens",1,15,6,12,530,31],
["2026-08-19","PUBG","Ghost","Storm Unit","Iron Pulse",0,4,5,3,320,27],
["2026-08-19","PUBG","Karma","Storm Unit","Iron Pulse",1,7,2,7,515,27],
["2026-08-20","Counter-Strike 2","Stryker","Iron Pulse","Dragon Core",1,26,12,4,420,40],
["2026-08-20","Counter-Strike 2","Hex","Iron Pulse","Dragon Core",1,21,15,11,380,40]
].map(r=>({date:r[0],game:r[1],player:r[2],team:r[3],opponent:r[4],win:!!r[5],kills:r[6],deaths:r[7],assists:r[8],score:r[9],duration:r[10]}));
const $=id=>document.getElementById(id);
const gameFilter=$("gameFilter"), teamFilter=$("teamFilter"), searchInput=$("searchInput");
[...new Set(DATA.map(d=>d.game))].sort().forEach(v=>gameFilter.add(new Option(v,v)));
[...new Set(DATA.map(d=>d.team))].sort().forEach(v=>teamFilter.add(new Option(v,v)));
function avg(a){return a.length?a.reduce((s,n)=>s+n,0)/a.length:0}
function pct(n,d){return d?Math.round(n/d*100):0}
function filtered(){const g=gameFilter.value,t=teamFilter.value,q=searchInput.value.trim().toLowerCase();return DATA.filter(d=>(g==="All"||d.game===g)&&(t==="All"||d.team===t)&&(!q||[d.player,d.team,d.game,d.opponent].some(x=>x.toLowerCase().includes(q))))}
function render(){
 const rows=filtered(),wins=rows.filter(d=>d.win).length,losses=rows.length-wins;
 $("datasetCount").textContent=DATA.length;
 $("winRate").textContent=pct(wins,rows.length)+"%";
 $("avgKD").textContent=(avg(rows.map(d=>d.kills))/Math.max(.1,avg(rows.map(d=>d.deaths)))).toFixed(2);
 $("avgScore").textContent=Math.round(avg(rows.map(d=>d.score))).toLocaleString();
 $("avgDuration").textContent=avg(rows.map(d=>d.duration)).toFixed(1);
 $("donutPct").textContent=pct(wins,rows.length)+"%";
 $("donut").style.background=`conic-gradient(var(--lime) 0% ${pct(wins,rows.length)}%,#303a4a ${pct(wins,rows.length)}% 100%)`;
 $("winsLegend").textContent=wins;$("lossesLegend").textContent=losses;
 const games={};rows.forEach(d=>games[d.game]=(games[d.game]||0)+1);
 const max=Math.max(1,...Object.values(games));
 $("gameChart").innerHTML=Object.entries(games).sort((a,b)=>b[1]-a[1]).map(([g,n])=>`<div class="bar-row"><span class="bar-label" title="${g}">${g}</span><div class="bar-track"><div class="bar-fill" style="width:${n/max*100}%"></div></div><span class="bar-num">${n}</span></div>`).join("")||'<div class="empty">No matching records</div>';
 const players={};rows.forEach(d=>{const k=d.player+"|"+d.team+"|"+d.game;(players[k]??=[]).push(d)});
 const leaderboard=Object.entries(players).map(([k,a])=>{const [player,team,game]=k.split("|");return {player,team,game,matches:a.length,score:avg(a.map(d=>d.score)),kd:avg(a.map(d=>d.kills))/Math.max(.1,avg(a.map(d=>d.deaths))),win:pct(a.filter(d=>d.win).length,a.length)}}).sort((a,b)=>b.score-a.score).slice(0,10);
 $("leaderboard").innerHTML=leaderboard.map((p,i)=>`<tr><td>${String(i+1).padStart(2,"0")}</td><td class="player">${p.player}</td><td>${p.team}</td><td>${p.game}</td><td>${p.matches}</td><td>${Math.round(p.score)}</td><td>${p.kd.toFixed(2)}</td><td>${p.win}%</td></tr>`).join("")||'<tr><td colspan="8" class="empty">No matching players</td></tr>';
 $("recordLabel").textContent=`${rows.length} RECORDS`;
 $("records").innerHTML=rows.slice(0,30).map(d=>`<tr><td>${d.date}</td><td>${d.game}</td><td class="player">${d.player}</td><td>${d.team}</td><td>${d.opponent}</td><td><span class="result ${d.win?"win":"loss"}">${d.win?"WIN":"LOSS"}</span></td><td>${d.kills} / ${d.deaths} / ${d.assists}</td><td>${d.score}</td><td>${d.duration} min</td></tr>`).join("")||'<tr><td colspan="9" class="empty">No matching records</td></tr>';
}
function exportCSV(){const rows=filtered();const headers=["date","game","player","team","opponent","result","kills","deaths","assists","score","duration_minutes"];const csv=[headers.join(","),...rows.map(d=>[d.date,d.game,d.player,d.team,d.opponent,d.win?"Win":"Loss",d.kills,d.deaths,d.assists,d.score,d.duration].map(v=>`"${String(v).replace(/"/g,'""')}"`).join(","))].join("\r\n");const a=document.createElement("a");a.href=URL.createObjectURL(new Blob([csv],{type:"text/csv;charset=utf-8;"}));a.download="esports_filtered_analytics.csv";a.click();URL.revokeObjectURL(a.href)}
gameFilter.addEventListener("change",render);teamFilter.addEventListener("change",render);searchInput.addEventListener("input",render);$("resetBtn").addEventListener("click",()=>{gameFilter.value="All";teamFilter.value="All";searchInput.value="";render()});$("exportBtn").addEventListener("click",exportCSV);render();